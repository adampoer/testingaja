<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>testing aja</title>
</head>

<body>
    <nav id="navbar"> 
        <div>
            <h1>adam sexy</h1>
        </div>

        <div>
            <input type="text" placeholder="Search" id="search">
        </div>

        <div id="menus">
            <div>
                <button type="submit" onclick="document.location='login.php'">Login</button>
            </div>
            <div>
                <button type="submit" onclick="document.location='register.php'">Register</button>
            </div>
        </div>   
    </nav>
</body>

</html>

